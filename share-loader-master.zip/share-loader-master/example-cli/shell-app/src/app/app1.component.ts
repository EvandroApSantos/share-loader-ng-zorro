import { Component } from '@angular/core';

@Component({
  selector: 'my-app1',
  styles: [`
    
  `],
  template: `
    <h1>I am an internal component</h1>
  `
})
export class App1Component {
}