import 'core-js';
import 'zone.js';

import '@angular/common';
import '@angular/compiler';
import '@angular/core';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/upgrade';
import '@angular/http';
import '@angular/router';
import 'rxjs';

import '@uirouter/angular';
import '@uirouter/rx';