import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {ExtModule} from './ext.module';

platformBrowserDynamic().bootstrapModule(ExtModule);